// Greg Stitt
// University of Florida
// main.cpp
//

#include <iostream>
#include <cstdlib>
#include <cassert>
#include <cstring>
#include <cstdio>
#include <vector>

#include "Board.h"

using namespace std;

#define TEST_SIZE 10000

//#define DEBUG
int fibbonaci(int val)
{
	int a =0;
	int b =1;
	if (val == 1)
	{
		a = a+b;
		return a;
	}
	else
	{
		for (int i=2;i<=val;i++)
		{
			int temp = a+b;
			a = b;
			b = temp;
		}
	}
	return b;
}


int main(int argc, char* argv[]) {
  unsigned GO_ADDR[2];
  unsigned N_ADDR = 1;
  unsigned RESULT_ADDR = 2;
  unsigned DONE_ADDR =3; 
  unsigned assert = 1;
  //unsigned stop= 0;
  unsigned result,done;
  unsigned i;
  GO_ADDR[0]=0;
  if (argc != 2) {
    cerr << "Usage: " << argv[0] << " bitfile" << endl;
    return -1;
  }
  
  vector<float> clocks(Board::NUM_FPGA_CLOCKS);
  clocks[0] = 100.0;
  clocks[1] = 100.0;
  clocks[2] = 100.0;
  clocks[3] = 100.0;
  
  cout << "Programming FPGA...." << endl;

  // initialize board
  Board *board;
  try {
    board = new Board(argv[1], clocks);
  }
  catch(...) {
    exit(-1);
  }
  
  for (i=1; i<= 30;i++)
  {	  
	  board->write(&i, N_ADDR, 1);
	  board->write(&assert, GO_ADDR[0], 1); 
	  board->read(&done, DONE_ADDR, 1);
	  board->read(&result, RESULT_ADDR, 1);
	  //board->write(&stop, GO_ADDR[0], 1);
	  cout <<i <<": HW = "<< result<<", SW = "<<fibbonaci(i)<<endl;
  }
  return 1;
}
